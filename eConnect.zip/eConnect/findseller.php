<?php
session_start();
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">

<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>


</div>
<div class="topmenu">
<ul>
  <li><a href="userhome.php">Home</a></li>
  <li><a href="userviewprofile.php">View Profile</a></li>
  <li><a href="findseller.php">Find Seller</a></li>
 
  <li><a href="viewuserrequest.php">View Request</a></li>
  <li><a href="logout.php" style="text-decoration:none"><b>Signout</b></a></li>
  
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>



<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div align="center" style="background:#CCC">

  <table width="347" height="69" bgcolor="#CCCCCC" >
  <form>
    <tr>
      <td>Search By Service</td>
      <td><select name="cat" id="cat" >
        <option value="">Select Service</option>
        <?php
  include("dbcon.php");
  $ser_qry="select * from categories";
  $ser_db=mysql_query($ser_qry);
  while($ser_values=mysql_fetch_array($ser_db))
  {
?>
        <option values="<?php echo $ser_values["category"];?>"><?php echo $ser_values["category"];?></option>
        <?php
  }
  ?>
      </select></td>
      <td><input type="submit" /></td>
    </tr>
    </form>
  </table>

</div>
<p>&nbsp;</p>
<p>













  <?php
if(isset($_REQUEST["requested"]))
{
	echo "Your Request Posted Succesfully....";
}
?>
  <?php
  if(isset($_REQUEST["cat"]))
  {
	  $sn=$_REQUEST["cat"];
  }
  else
  {
	 $sn="null";  
  }
  include("dbcon.php");
  $ser_qry26="select * from services where service_nam='".$sn."'";
  $ser_db26=mysql_query($ser_qry26);
  $v=0;
  ?>
</p>
<table width="913" height="154" align="center">
 
 
  <?php
  while($ser_values26=mysql_fetch_array($ser_db26))
  {
	  $v++;
	  $photos=$ser_values26["photo"];
	  $Service_name=$ser_values26["service_nam"];
	  $Service_des=$ser_values26["Service_des"];
	  $contactdet1=$ser_values26["sellername"];
	  $contactdet2=$ser_values26["email"];
	  $contactdet3=$ser_values26["phone"];
	  $contactdet4=$ser_values26["location"];
	  $contactdet5=$ser_values26["serviceid"];
	  if($v==1)
	  {
		  ?>
	     <tr bgcolor="#999999" style="font-family:Verdana, Geneva, sans-serif;">
  <td ><b>Service Type</b></td>
  

  <td ></td>
  
    
    <td  ><b>Contact Details</b></td>
    <td><b>Request Form</b></td>
    
  </tr>
		  <?php
	  }
?>

 <tr style="background:#FF6">
 <td  ><h1><b><?php echo strtoupper($sn); ?></b></h1></td>
 <td ><img width="205" height="193" src="userdp/<?php echo $photos; ?>"</td>

 <td ><?php  echo $contactdet1,"</br>",$contactdet2,"</br>",$contactdet3,"</br>",$contactdet4,"</br>","</br>","</br>","</br>"; ?></td>
<td><input type="button" value="Request" onClick="window.location='viewseller.php?cat=<?php echo $sn; ?>&serid=<?php echo $contactdet5; ?>'"/></td>
 </tr>

<?php
  }
?>
</table>



</body>
</html>

























