<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">

</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157">
 
 </div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>

</div>
</div>
<div class="row2">
<center >
<h1 style="width:900;background-color:#CCC">E-Connect</h1><br />




</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>
<?php
session_start();
echo $usermail=$_REQUEST["usermail"];
echo $password=$_REQUEST["pass"];
if(empty($usermail)|| empty($password)){
	$message = "Pls fill all the filed";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='user.php'
		 window.alert('$message')
        </SCRIPT>");
}
include("dbcon.php");
$userlogin_qry="select * from user where mail='".$usermail."' and password='".$password."'";
$rs1=mysql_query($userlogin_qry);
echo $coun=mysql_num_rows($rs1);
if($coun>0)
{
	$_SESSION["usermail"]=$usermail;
	
	$message = "Successfull Login";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='userhome.php'
		 window.alert('$message')
        </SCRIPT>");
}
else
{
	$message = "Username or password incorrect";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='user.php'
		 window.alert('$message')
        </SCRIPT>");
	
}


?>