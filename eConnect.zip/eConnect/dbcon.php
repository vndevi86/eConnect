<?php
$con=mysql_connect("localhost","root","") OR die("Failed Connecting To Mysql");
mysql_select_db("e_connect") OR die("Failed Connecting To Database");
?>