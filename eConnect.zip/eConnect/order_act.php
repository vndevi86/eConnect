<?php
echo $ser_dat=$_REQUEST["serdate"];
echo $sertime=$_REQUEST["sertime"];
echo $seller_id=$_REQUEST["srsellermail"];
echo $user_id=$_REQUEST["srusermail"];
echo $categ=$_REQUEST["cat"];
echo $dat=date("Y/m/d");

include("dbcon.php");
$srinsert="insert into order_tab(user_id,seller_id,categ,req_date,req_time,counter) VALUES('".$user_id."','".$seller_id."','".$categ."','".$ser_dat."','".$sertime."',0)";
echo $retval=mysql_query($srinsert);
if($retval==1)
{
header("location:findseller.php?requested=yes");
}
?>