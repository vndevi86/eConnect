<?php
session_start();
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="userhome.php">Home</a></li>
  <li><a href="userviewprofile.php">View Profile</a></li>
  <li><a href="findseller.php">Find Seller</a></li>
 
  <li><a href="viewuserrequest.php">View Request</a></li>
  <li><a href="logout.php" style="text-decoration:none"><b>Signout</b></a></li>
  
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157">
 
 </div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size:14px;background-color:#CCC;font-size:18px" ><?php echo "Welcome..",$_SESSION["usermail"]; ?>
 </span></p>
</div>
</div>
<div class="row2">
<center >
<h1 style="width:900;background-color:#CCC">Business-to-Business Services</h1><br />
<p align="justify" style="width:800;height:260;line-height:2;background-color:">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Business-to-business (B2B) refers to a situation where one business makes a commercial transaction with another. This typically occurs when:A business is sourcing materials for their production process, e.g. a food manufacturer purchasing salt. A business needs the services of another for operational reasons, e.g. a food manufacturer employing an accountancy firm to audit their finances. A business re-sells goods and services produced by others, e.g. a retailer buying the end product from the food manufacturer Contrasting terms are business-to-consumer (B2C) and business-to-government (B2G). The overall volume of B2B (Business-to-Business) transactions is much higher than the volume of B2C transactions. The primary reason for this is that in a typical supply chain there will be many B2B transactions involving sub components or raw materials,and only one B2C transaction, specifically sale of the finished product to the end customer. For example, an automobile manufacturer makes several B2B transactions such as buying tires, glass for windscreens, and rubber hoses for its vehicles. The final transaction, a finished vehicle sold to the consumer,is a single (B2C) transaction.</p><center>





</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>




























