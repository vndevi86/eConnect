<?php
$stat=$_REQUEST["stat"];
$smailid=$_REQUEST["smail"];
echo $stat;
include("dbcon.php");
if($stat==0)
{
	$updateseller="update seller set status='1' where mail='".$smailid."'";
	$execqry=mysql_query($updateseller);
	header("location:adminhome.php");
}
?>