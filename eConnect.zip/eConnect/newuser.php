<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="admin.php">Admin</a></li>
  <li><a href="seller.php">Seller</a></li>
  <li><a href="user.php">User</a></li>
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157"></div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
</div>
</div>
<div class="row2">



<h1 align="center">User Registration</h1>
<form action="userregister.php">
<table width="313" height="358" align="center">
<tr>
<td>Enter Firstname</td><td><input type="text" name="fname" id="fname"></td>
</tr>
<tr>
<td>Enter Lastname</td><td><input type="text" name="lname" id="lname"></td>
</tr>
<tr>
<td>Enter Password</td><td><input type="password" name="pass" id="pass"></td>
</tr>
<tr>
<td>Confirm Password</td><td><input type="password" name="cpass" id="cpass"></td>
</tr>
<tr>
<td>E-mail</td><td><input type="email" name="mail" id="mail"></td>
</tr>
<tr>
<td>Age</td><td><input type="text" name="age" id="age"></td>
</tr>
<tr>
<td>D.O.B</td><td><input type="text" name="dob" id="dob"></td>
</tr>
<tr>
<td>Mobile</td><td><input type="text" name="mob" id="mob"></td>
</tr>

<tr>
<td>Gender</td><td><input type="radio" name="gen" id="gen" value="male">Male<input type="radio" name="gen" id="gen" value="female">Fe Male</td>
</tr>

<tr>
<td><input type="submit"></td><td><a href="user.php">Back</a></td>       
</tr>



</table>
</form>
<table align="center">
<tr>
<td>
<?php
if(isset($_REQUEST["sucmsg"]))
{
	echo $sucmsg="User Registerd Scuuesfully. . . !";
}
else
{
	
}
?>
</td>
</tr>
</table>



</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>


























