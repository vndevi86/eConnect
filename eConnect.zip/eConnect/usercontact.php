
<?php
session_start();
?>
<p><h1 align="center" style="background-color:gray">Welcome to eConnect </h1>  </p>
<span style="font-size:14px;background-color:#CCC;font-size:18px"><?php echo "Welcome..",$_SESSION["usermail"]; ?> &nbsp; &nbsp; &nbsp; &nbsp; <a href="logout.php"><b>Signout</b></a></span>
</br></br>

<table width="773" height="39" border="0" align="center">
<tr>
<td width="88" style="background-color:#CCC;" align="center"><a href="userhome.php" style="font-size:22px;text-decoration:none">Home</td>
<td width="138" style="background-color:#CCC;" align="center"><a href="userviewprofile.php" style="font-size:22px;text-decoration:none">View Profile</td>
<td width="128" style="background-color:#CCC;" align="center"><a href="findseller.php" style="font-size:22px;text-decoration:none">Find Seller</td>
<td width="102" style="background-color:#CCC;" align="center"><a href="usercontact.php" style="font-size:40px;text-decoration:none">Contact</td>
</tr>
</table>
</br>
</br>
<center>
<h1></h1>
<h1 style="width:1000;background-color:#CCC">Contact</h1>
  <center>
  <table>
  <tr><td></td></tr>
  </table>
