<?php
session_start();
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>



<div align="center">
<div class="header-top" >
<h1 align="center">E-<span>Connect</span></h1>
<h1 align="center"><span>Seler Details</span></h1>
<p>Call Us: 1800000000</p>
<p><a href="findseller.php">Back</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php">Logout</a></p>
</div>

</div>
<br><br>

 
  <center >




<?php
if(isset($_REQUEST["requested"]))
{
	echo "Your Request Posted Succesfully....";
}
?>
  <?php
  if(isset($_REQUEST["cat"]) && isset($_REQUEST["serid"]))
  {
	  $sn=$_REQUEST["cat"];
	  $sn1=$_REQUEST["serid"];
  }
  else
  {
	 $sn="null";  
  }
  include("dbcon.php");
  $ser_qry26="select * from services where service_nam='".$sn."' and serviceid='".$sn1."'";
  $ser_db26=mysql_query($ser_qry26);
  $v=0;
  ?>
  
  <table width="1442" height="226" >
 
 
  <?php
  while($ser_values26=mysql_fetch_array($ser_db26))
  {
	  $v++;
	  $photos=$ser_values26["photo"];
	  $Service_name=$ser_values26["service_nam"];
	  $Service_des=$ser_values26["Service_des"];
	  $contactdet1=$ser_values26["sellername"];
	  $contactdet2=$ser_values26["email"];
	  $contactdet3=$ser_values26["phone"];
	  $contactdet4=$ser_values26["location"];
	  if($v==1)
	  {
		  ?>
		   <tr bgcolor="#999999" style="font-family:Verdana, Geneva, sans-serif;">
  <td ><b>Service Type</b></td>
  <td></td>
  <td><b>Service Description</b></td>
  <td width="52"><b>Contact Details</b></td>
    <td width="52"><b>Request Form</b></td>
  </tr>
		  <?php
	  }
?>

 <tr style="background:#FF6">
 <td width="221" ><h1><b><?php echo strtoupper($sn); ?></b></h1></td>
 <td width="150" ><img width="205" height="193" src="userdp/<?php echo $photos; ?>"</td>
 <td width="352"><?php  echo $Service_des; ?></td>
 <td width="352"><?php  echo $contactdet1,"</br>",$contactdet2,"</br>",$contactdet3,"</br>",$contactdet4,"</br>","</br>","</br>","</br>"; ?></td>
 <td>
 <table>
 <form action="order_act.php">
 <tr>
 <td>Enter Service Date</td>
 <td><input type="date" name="serdate"></td>
 </tr>
 <tr>
 <td>Enter Service Time</td>
 <td>
 <input type="text" name="sertime">
 <input type="hidden" name="srsellermail" value="<?php echo $contactdet2; ?>">
 <input type="hidden" name="srusermail" value="<?php echo $_SESSION["usermail"]; ?> ">
 <input type="hidden" name="cat" value="<?php echo $Service_name; ?>">
 </td>
 </tr>
 <tr>
 <td><input type="submit" value="REQUEST"></td>
 </tr>
 </table>
 </form>
 </td>
 </tr>

<?php
  }
?>
 </table>

<blockquote>&nbsp;																																																																																																																																																																																																							</blockquote>


</div>
</div>
</div>
</div>


</body>
</html>





































