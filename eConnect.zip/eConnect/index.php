<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="#">About Us</a></li>
  <li><a href="admin.php">Admin</a></li>
  <li><a href="seller.php">Seller</a></li>
  <li><a href="user.php">User</a></li>
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157"></div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
</div>
</div>
<div class="row2">
<div class="section1">
<h2 class="subtitle">What&#8217;s New</h2>
<p align="justify">While companies pay hefty fees to this growing body of professional consultants and advisers, the amount paid out for fees is quite small if compared to the dollars at stake when companies follow the advice of professional consultants. Yet management has far less experience in buying professional services than it has in buying goods and equipment. Unfortunately, the tried and true rules for buying goods do not work when applied to the buying of professional services. Many a management has gone badly astray by applying the same rules that have served well over the years in building a plant or investing in capital equipment to the hiring of professional consultation.</p>

</div>
<div class="section2">
<h2 class="subtitle">Resources</h2>
<p> recent years, there has been a marked increase in the buying of professional services by management. This is true for a broad range of advisory activities, such as financial, economic, public relations, advertising, legal, personnel, research, and many others. By the same token, there has been a marked growth in the firms selling these services.</p>
<br>
<p>Buy Services</p></br>
<p>Sell Services</p><br>
<p>On Time Service Delivery</p><br>
</div>
</div>
</div>
<div class="content-right">
<h2><a href="user.php">Buy Service</a>&nbsp;&nbsp;<br><br><a href="seller.php">Sell Service</a></h2>
<ul>

</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>
