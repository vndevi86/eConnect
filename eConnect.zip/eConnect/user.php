<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="admin.php">Admin</a></li>
  <li><a href="seller.php">Seller</a></li>
  <li><a href="user.php">User</a></li>
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157"></div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
</div>
</div>
<div class="row2">



<h1 align="center">&nbsp;</h1>
<h1 align="center">&nbsp;</h1>
<h1 align="center">User Login</h1>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<form action="userlogin.php">
<table width="405" height="194" align="center">
<tr>
<td>Enter E-mail</td><td><input type="text" name="usermail" id="usermail"></td>
</tr>
<tr>
<td>Enter Password</td><td><input type="password" name="pass" id="pass"></td>
</tr>
<tr>
<td><input type="submit"><td><a href="forgetuser.php">Forget Password!</a></td></td>
</tr>
<tr align="center">
<td> <a href="newuser.php">New User Registration!</a> </td><td><a href="index.php">Home</a></td>

</tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</form>






</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>

