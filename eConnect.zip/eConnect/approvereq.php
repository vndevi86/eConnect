<?php 
include("dbcon.php");
$id=$_REQUEST["reqid"];
$qry="update order_tab set counter=1 where req_id='".$id."'";
mysql_query($qry);
header("location:sellerviewrequest.php");
?>