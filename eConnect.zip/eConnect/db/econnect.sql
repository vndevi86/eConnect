/*
SQLyog Community v8.4 RC2
MySQL - 5.6.20 : Database - e_connect
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`e_connect` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `e_connect`;

/*Table structure for table `categories` */

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `category` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `categories` */

insert  into `categories`(`category`) values ('Photographer'),('plumber'),('wedding planner'),('bridal makeup'),('Electrician'),('Carpenter'),('Laundry'),('Housemaid'),('Driver '),('TV/AC repair'),('Car repair'),('Painter');

/*Table structure for table `order_tab` */

DROP TABLE IF EXISTS `order_tab`;

CREATE TABLE `order_tab` (
  `req_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) DEFAULT NULL,
  `seller_id` varchar(100) DEFAULT NULL,
  `categ` varchar(100) DEFAULT NULL,
  `req_date` varchar(100) DEFAULT NULL,
  `req_time` varchar(100) DEFAULT NULL,
  `counter` int(5) DEFAULT NULL,
  UNIQUE KEY `req_id` (`req_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `order_tab` */

insert  into `order_tab`(`req_id`,`user_id`,`seller_id`,`categ`,`req_date`,`req_time`,`counter`) values (1,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','2016-02-16','12:54',0),(2,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','2016-02-16','12:54',0),(3,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','2016-02-16','12:54',0),(4,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','2016-02-25','12:56',0),(5,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','2016-02-06','13:54',0),(6,'mail.prashanthsekar@gmail.com ','simbu@uniqtechnologies.co.in','TV/AC repair','','12:54',0),(7,'prashanthsekar@uniqtechnologies.co.in ','simbu@uniqtechnologies.co.in','TV/AC repair','','',0),(8,'prashanthsekar@uniqtechnologies.co.in ','prashanthsekar@uniqtechnologies.co.in','TV/AC repair','','',0);

/*Table structure for table `seller` */

DROP TABLE IF EXISTS `seller`;

CREATE TABLE `seller` (
  `sid` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `age` int(5) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `status` int(5) DEFAULT NULL,
  UNIQUE KEY `sid` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `seller` */

insert  into `seller`(`sid`,`fname`,`lname`,`password`,`cpassword`,`mail`,`age`,`dob`,`mobile`,`gender`,`status`) values (1,'Simbu','star','12345','12345','simbu@uniqtechnologies.co.in',18,'28/05/1992','9940806569','male',NULL);

/*Table structure for table `services` */

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `serviceid` int(5) NOT NULL AUTO_INCREMENT,
  `sellerid` int(5) DEFAULT NULL,
  `sellername` varchar(100) DEFAULT NULL,
  `service_nam` varchar(100) DEFAULT NULL,
  `Service_des` longtext,
  `location` varchar(100) DEFAULT NULL,
  `photo` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `date_time` varchar(100) DEFAULT NULL,
  UNIQUE KEY `serviceid` (`serviceid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `services` */

insert  into `services`(`serviceid`,`sellerid`,`sellername`,`service_nam`,`Service_des`,`location`,`photo`,`email`,`phone`,`date_time`) values (1,1,'Simbu star','TV/AC repair','“Mepserv supports all your technical needs, like AC (Air conditioner) repair services, Electrical repair services & plumbing repair services in chennai and other cities are in pipe-line.\r\n \r\nWe have our own in-house team to carry out all the service request you made. Unlike others we do it with our staff to ensure your safety.\r\n \r\nMepserv also offers you hassle free payment, Mepserv is the only site offers transparent price tag in all products and our technician never charge you more than that.\r\n \r\nAC(Air conditioner) repair service, electrical repair service and plumbing repair service are our core business and other domestic services are in pipe-line. You can call us or order online for your booking and no worry if you unable to find relevant product, we have option to call a plumber of call an ac technician or an electrician\"','T.nagar','19be84_cd45731f90e644c48eeecb8ccbcda9fc.jpg','simbu@uniqtechnologies.co.in','9940806569','2016/02/15'),(3,2,'prashanth','TV/AC repair',NULL,'namakkal','19be84_cd45731f90e644c48eeecb8ccbcda9fc.jpg','prashanthsekar@uniqtechnologies.co.in','9940806569','2016/02/15'),(4,3,'prashanth','TV/AC repair','ffffffffTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repairTV/AC repair','Namakkal','19be84_cd45731f90e644c48eeecb8ccbcda9fc.jpg','prashanthsekar@uniqtechnologies.co.in','9940806569','2016/02/15');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `cpassword` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `age` int(5) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`fname`,`lname`,`password`,`cpassword`,`mail`,`age`,`dob`,`mobile`,`gender`,`status`) values ('Prashanth','Sekar','12345','12345','prashanthsekar@uniqtechnologies.co.in',23,'28/05/1992','07373340635','male',NULL),('Prashanth','Sekar','12345','12345','mail.prashanthsekar@gmail.com',1,'29-NOV-2015','0123456789','male',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
