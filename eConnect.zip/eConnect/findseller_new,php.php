<?php
session_start();
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="userhome.php">Home</a></li>
  <li><a href="userviewprofile.php">View Profile</a></li>
  <li><a href="findseller.php">Find Seller</a></li>
 
  <li><a href="viewuserrequest.php">View Request</a></li>
  <li><a href="logout.php" style="text-decoration:none"><b>Signout</b></a></li>
  
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157">
 
 </div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size:14px;background-color:#CCC;font-size:18px" ><?php echo "Welcome..",$_SESSION["usermail"]; ?>
 </span></p>
</div>
</div>
<div class="row2">
<center >
<h1 style="width:900;background-color:#CCC">Find Your Seller-Your Prefered Catogoery</h1><br />


<form action="findseller.php" id="catform">
<table >
<tr>
<td><select name="cat" id="cat" >
<option value="">Select Service</option>
  <?php
  include("dbcon.php");
  $ser_qry="select * from categories";
  $ser_db=mysql_query($ser_qry);
  while($ser_values=mysql_fetch_array($ser_db))
  {
?>

<option values="<?php echo $ser_values["category"];?>"><?php echo $ser_values["category"];?></option>
<?php
  }
  ?>

</select></td>
<td><input type="submit"></td>
</tr>
</table>
</form>

<?php
if(isset($_REQUEST["requested"]))
{
	echo "Your Request Posted Succesfully....";
}
?>
  <?php
  if(isset($_REQUEST["cat"]))
  {
	  $sn=$_REQUEST["cat"];
  }
  else
  {
	 $sn="null";  
  }
  include("dbcon.php");
  $ser_qry26="select * from services where service_nam='".$sn."'";
  $ser_db26=mysql_query($ser_qry26);
  $v=0;
  ?>
  
  <table width="1442" height="226" >
 
 
  <?php
  while($ser_values26=mysql_fetch_array($ser_db26))
  {
	  $v++;
	  $photos=$ser_values26["photo"];
	  $Service_name=$ser_values26["service_nam"];
	  $Service_des=$ser_values26["Service_des"];
	  $contactdet1=$ser_values26["sellername"];
	  $contactdet2=$ser_values26["email"];
	  $contactdet3=$ser_values26["phone"];
	  $contactdet4=$ser_values26["location"];
	  if($v==1)
	  {
		  ?>
		   <tr bgcolor="#999999" style="font-family:Verdana, Geneva, sans-serif;">
  <td ><b>Service Type</b></td>
  <td></td>
  <td><b>Service Description</b></td>
  <td width="52"><b>Contact Details</b></td>
    <td width="52"><b>Request Form</b></td>
  </tr>
		  <?php
	  }
?>

 <tr style="background:#FF6">
 <td width="221" ><h1><b><?php echo strtoupper($sn); ?></b></h1></td>
 <td width="150" ><img width="205" height="193" src="userdp/<?php echo $photos; ?>"</td>
 <td width="352"><?php  echo $Service_des; ?></td>
 <td width="352"><?php  echo $contactdet1,"</br>",$contactdet2,"</br>",$contactdet3,"</br>",$contactdet4,"</br>","</br>","</br>","</br>"; ?></td>
 <td>
 <table>
 <form action="order_act.php">
 <tr>
 <td>Enter Service Date</td>
 <td><input type="date" name="serdate"></td>
 </tr>
 <tr>
 <td>Enter Service Time</td>
 <td>
 <input type="text" name="sertime">
 <input type="hidden" name="srsellermail" value="<?php echo $contactdet2; ?>">
 <input type="hidden" name="srusermail" value="<?php echo $_SESSION["usermail"]; ?> ">
 <input type="hidden" name="cat" value="<?php echo $Service_name; ?>">
 </td>
 </tr>
 <tr>
 <td><input type="submit" value="REQUEST"></td>
 </tr>
 </table>
 </form>
 </td>
 </tr>

<?php
  }
?>
 </table>
<blockquote>&nbsp;																																																																																																																																																																																																							</blockquote>


</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>

























