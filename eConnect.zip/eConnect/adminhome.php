<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="admin.php">Admin</a></li>
  <li><a href="seller.php">Seller</a></li>
  <li><a href="user.php">User</a></li>
      <li><a href="logout.php" style="text-decoration:none"><b >Signout</b></a></li>
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157"></div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
</div>
</div>
<div class="row2">
<h1 align="center">&nbsp;</h1>
<h1 align="center">&nbsp;</h1>
<h1 align="center">Seller Details</h1>

<p align="center">&nbsp;</p>
<table width="568" height="52" border="1"  align="center">
<tr>
<td>Seller Id</td>
<td>Seller Name</td>
<td>Mail</td>
<td>DOB</td>
<td>Mob</td>

<td>Status</td>
</tr>
<?php 
include("dbcon.php");
$qry="select * from seller";
$qryres=mysql_query($qry);
while($qryres1=mysql_fetch_array($qryres))
{
$selid=$qryres1["sid"];	
$selname=$qryres1["fname"];	
$selmail=$qryres1["mail"];	
$dob=$qryres1["dob"];	
$mob=$qryres1["mobile"];
$sta=$qryres1["status"];	
?>
<tr>
<td><?php echo $selid; ?></td>
<td><?php echo $selname; ?></td>
<td><?php echo $selmail; ?></td>
<td><?php echo $dob; ?></td>
<td><?php echo $mob; ?></td>

<?php
if($sta==0)
{
?>
<td> <a href="adminappr.php?stat=<?php echo $sta; ?>&smail=<?php echo $selmail; ?>">Approve</a> </td>
<?php
}
else
{
?>
<td>Approved</td>
</tr>

<?php
}
}
?>
</table>
</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>

</div>
</div>
</div>
</body>
</html>

