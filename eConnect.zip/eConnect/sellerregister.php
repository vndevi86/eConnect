<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">

</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157">
 
 </div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>

</div>
</div>
<div class="row2">
<center >
<h1 style="width:900;background-color:#CCC">E-Connect</h1><br />




</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>

<?php
$sellerfname=$_REQUEST["sfname"];
$sellerlname=$_REQUEST["slname"];
$sellerpass=$_REQUEST["spass"];
$sellercpass=$_REQUEST["scpass"];
$selleremail=$_REQUEST["smail"];
$sellerage=$_REQUEST["sage"];
$sellerdob=$_REQUEST["sdob"];
$sellermob=$_REQUEST["smob"];
$sellergen=$_REQUEST["sgen"];
$test_date =$_REQUEST["sdob"];
if(empty($sellerfname) || empty($sellerlname)  || empty($sellerpass)  || empty($sellercpass)  || empty(selleremail) || empty($sellerage)  || empty($sellerdob) || empty($sellermob) || empty($sellergen)){
	 $message = "Please fill all the fields.";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='newseller.php'
		 window.alert('$message')
        </SCRIPT>");
}

$test_arr  = explode('/', $test_date);
if (count($test_arr) == 3) {
    if (checkdate($test_arr[0], $test_arr[1], $test_arr[2])) {
       
    } 
} else {
    $message = "Prob with date , format (dd/mm/yy).\\nTry again.";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='newseller.php'
		 window.alert('$message')
        </SCRIPT>");
}
if(($sellerpass==$sellercpass)&& ereg("^[0-9]{3}[0-9]{3}[0-9]{4}$", $sellermob)){
include("dbcon.php");
$sellerinsert_qry="insert into seller(fname,lname,password,cpassword,mail,age,dob,mobile,gender,status) VALUES('".$sellerfname."','".$sellerlname."','".$sellerpass."','".$sellercpass."','".$selleremail."','".$sellerage."','".$sellerdob."','".$sellermob."','".$sellergen."','0')";
$ret_val1=mysql_query($sellerinsert_qry);
echo $ret_val1;
if($ret_val1==1)
{
	$message = "Registered Successfully.";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='newseller.php?sucmsg=suc'
		 window.alert('$message')
        </SCRIPT>");

}
}
else{
		
	$message = "Password and ConfirmPassword MissMatch or invalid phonenumber.\\nTry again.";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='newseller.php'
		 window.alert('$message')
        </SCRIPT>");
}
?>