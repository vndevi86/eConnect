<?php
$adminname=$_REQUEST["admin"];
$adminpass=$_REQUEST["apass"];

if(empty($adminname)|| empty($adminpass)){
	$message = "Pls fill the required filelds";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='admin.php'
		 window.alert('$message')
        </SCRIPT>");
}
if($adminname=="admin" && $adminpass=="admin")
{
	
	$message = "Login Successfull";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='adminhome.php'
		 window.alert('$message')
        </SCRIPT>");
}


	else{
		
	$message = "Incorrect Username or Password.\\nTry again.";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
       
        window.location.href='admin.php'
		 window.alert('$message')
        </SCRIPT>");
}


?>