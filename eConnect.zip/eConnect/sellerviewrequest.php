
<?php
session_start();
?>
<html>
<head>
  <meta charset="UTF-8">
  <title>eConnect- Sell and buy any service</title>
  <meta name="description" content="Description of your site goes here">
  <meta name="keywords" content="keyword1, keyword2, keyword3">
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="main-out">
<div class="main">
<div class="page">
<div class="top">
<div class="header">
<div class="header-top">
<h1>E-<span>Connect</span></h1>
<p>Call Us: 1800000000</p>
</div>
<div class="topmenu">
<ul>
  <li><a href="sellerhome.php">Home</a></li>
  <li><a href="sellerviewprofile.php">View Profile</a></li>
  <li><a href="addservice.php">Add Service</a></li>
  <li><a href="myservice.php">My Service</a></li>
  <li><a href="sellerviewrequest.php">User Requests</a></li>
  <li><a href="logout.php" style="text-decoration:none"><b>Signout</b></a></li>
  
  
</ul>
</div>
<div class="header-img">
<h2>eConnect- Sell and buy any service</h2>
</div>
</div>
<div class="content">
<div class="content-left">
<div class="row1">
<div class="img"><img src="images/img1.jpg" alt="" height="101"
 width="157">
 
 </div>
<div class="welcome">
<h1 class="title">Welcome to E-Connect</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size:14px;background-color:#CCC;font-size:18px" ><?php echo "Welcome..",$_SESSION["sellermail"]; ?>
 </span></p>
</div>
</div>
<div class="row2">
<center >
<h1 style="width:900;background-color:#CCC">My Service</h1><br />



<table width="913" height="154" align="center">
<tr bgcolor="#999999" style="font-family:Verdana, Geneva, sans-serif;">
  <td width="81" ><b>Request Id</b></td>
  <td width="316"  ><b>User id</b></td>
    <td width="74"><b>Service Type</b></td>
     <td width="111"><b>Request Date</b></td>
     <td width="101"><b>Request Time</b></td>
     <td width="202"><b>Status</b></td>
     <td width="202"><b></b></td>
    
    
  </tr>
   <?php
   
 include("dbcon.php");
  $ser_qry26="select * from order_tab where seller_id='".$_SESSION["sellermail"]."'";
  $ser_db26=mysql_query($ser_qry26);
  

  while($ser_values26=mysql_fetch_array($ser_db26))
  {
	  
	  $a=$ser_values26["req_id"];
	  $b=$ser_values26["user_id"];
	  $c=$ser_values26["categ"];
	  $d=$ser_values26["req_date"];
	  $e=$ser_values26["req_time"];
	  $status=$ser_values26["counter"];
	  

	 
?>
<tr style="background:#FF6">
<td><?php echo $a; ?></td>
<td><?php echo $b; ?></td>
<td><?php echo $c; ?></td>
<td><?php echo  $d; ?></td>
<td><?php echo  $e; ?></td>
<td><?php if($status==0) { echo  "Pending"; } else { echo "Approved"; } ?></td>
<td><input type="button" value="Approve" onClick="window.location='approvereq.php?reqid=<?php echo $a;?>'"> </td>
 </tr>
		  <?php
	  }
?>


</table>


</div>
</div>
</div>
</div>
<div class="bottom">
<ul>
  <li style="border-left: medium none;"><a href="index.html">Home</a></li>
  <li><a href="#">About&nbsp;Us</a></li>
  <li><a href="#">Admin</a></li>
  <li><a href="#">Seller</a></li>
  <li><a href="#">User</a></li>

</ul>

<!--DO NOT Remove The Footer Links-->
<p>&copy; Copyright 2016. Designed by <a  href="">HTML</a></p>
<!--Designed by--><a  href="">
<img src="images/footnote.gif" class="copyright" alt=""></a></div>
<!--DO NOT Remove The Footer Links-->
</div>
</div>
</div>
</body>
</html>
